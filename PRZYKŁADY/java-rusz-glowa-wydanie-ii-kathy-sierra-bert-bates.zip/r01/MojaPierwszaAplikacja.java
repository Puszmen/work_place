
class MojaPierwszaAplikacja {

  public static void main(String[] args) {
    System.out.println("Ja rządzę!");
    System.out.println("światem!");
  }
}
