class TestIf {
	public static void main(String[] args) {
		int x = 3;
    if (x == 3) {
      System.out.println("x musi mieć wartość 3");
    }
    System.out.println("Ta instrukcja zawsze zostanie wykonana");
	}
}
