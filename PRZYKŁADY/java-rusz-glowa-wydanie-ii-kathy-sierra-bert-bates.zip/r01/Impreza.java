import java.awt.*;
import java.awt.event.*;

class Impreza {
	public static void tworzZaproszenie(){
		Frame f = new Frame();
    Label l = new Label("Impreza u Tomka!");
    Button b = new Button("Się rozumie!");
    Button c = new Button("Zapomnij :-(");
    Panel p = new Panel();
    p.add(l);
    //... dalsza część kodu
	}
}
