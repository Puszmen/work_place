class TestIf2 {
	public static void main(String[] args) {
		int x = 2;
    if (x == 3) {
      System.out.println("x musi mieć wartość 3");
    } else {
      System.out.println("x jest RӯNE od 3!");
    }
    System.out.println("Ta instrukcja zawsze zostanie wykonana");
	}
}
