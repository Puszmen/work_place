public class Kaczka2 {
  int wielkosc;

  public Kaczka2() {
    // określenie domyślnej wielkości
    wielkosc = 27;
  }

  public Kaczka2(int wielkoscK) {
    // użycie parametru
    wielkosc = wielkoscK;
  }
}
