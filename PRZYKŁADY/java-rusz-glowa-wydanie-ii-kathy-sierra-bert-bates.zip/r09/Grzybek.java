public class Grzybek { 
  public Grzybek(int wielkosc) { }
  public Grzybek() { }
  public Grzybek(boolean czyMagiczny) { }
  public Grzybek(boolean czyMagiczny, int wielkosc) { }
  public Grzybek(int wielkosc, boolean czyMagiczny) { }
}