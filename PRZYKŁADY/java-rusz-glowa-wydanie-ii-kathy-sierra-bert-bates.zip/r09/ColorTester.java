import java.awt.*; 

public class ColorTester {
  public static void main(String[] args) {
    Color c = new Color();
    
  }
}