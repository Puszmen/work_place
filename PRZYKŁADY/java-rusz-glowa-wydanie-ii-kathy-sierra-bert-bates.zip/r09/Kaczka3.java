public class Kaczka3 extends Zwierze { 
  int wielkosc;

  public Kaczka3(int nowaWlksc) {
    Zwierze();
    wielkosc = nowaWlksc;
  }
}