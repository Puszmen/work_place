public class Boo { 
  public Boo(int i) {}
  public Boo(String s) {}
  public Boo(String s, int i) {}
}
