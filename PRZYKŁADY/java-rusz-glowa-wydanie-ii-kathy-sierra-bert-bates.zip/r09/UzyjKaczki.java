class Kaczka {
  public Kaczka() {
    System.out.println("Kwak");
  }
}
 
public class UzyjKaczki {
  public static void main(String[] args) {
    Kaczka k = new Kaczka();				
  }
}
