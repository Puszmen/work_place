import java.io.*;

class Pies implements Serializable {
  
  int wielkosc;
  String rasa;
  String nazwa;

  void szczekaj() {
    System.out.println("Chau! Chauuu!");
  }
}
