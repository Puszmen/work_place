class Test { 
  public void jazda() {
    int x;
    int z = x + 3;    		
  }
}
