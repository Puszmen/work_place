import java.lang.Math;  

class BezStatycznegoImportu {
  public static void main(String[] args) {
    System.out.println("Pierwiastek z dwóch to: " + Math.sqrt(2.0));
    System.out.println("Tangens: " + Math.tan(60));
  }
}
