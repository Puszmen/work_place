public class Bar { 
  public static final double BAR_MUZA;
  
  //*
  static {
    BAR_MUZA = (double) Math.random();
  }
  //*/
}
