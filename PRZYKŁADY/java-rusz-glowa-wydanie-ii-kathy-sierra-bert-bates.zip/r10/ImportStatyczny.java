import static java.lang.System.out;
import static java.lang.Math.*;

class ImportStatyczny {
  public static void main(String[] args) { 
    out.println("Pierwiastek z dwóch to: " + sqrt(2.0));
    out.println("Tangens: " + tan(60));
  }
}
