
public class Opakowania { 

	public static void main(String[] args) {
    String s = "dwa";
    int x = Integer.parseInt(s);          
    double d = Double.parseDouble("420.24");

    boolean b = new Boolean("true").booleanValue(); 

	}
}
