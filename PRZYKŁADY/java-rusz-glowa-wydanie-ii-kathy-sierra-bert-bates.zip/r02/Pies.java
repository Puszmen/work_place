class Pies {
  
  int wielkosc;
  String rasa;
  String nazwa;

  void szczekaj() {
    System.out.println("Chau! Chauuu!");
  }
}
