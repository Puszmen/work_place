class StarterGry {
  public static void main(String[] args) {
    Zgadywanka gra = new Zgadywanka();
    gra.rozpocznijGre();
  }
}