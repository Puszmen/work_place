/*

class PiesTester {
  public static void main (String[] args) {
    // Tutaj umieścimy kod testujący klasę Pies
  }
}

*/

//----------------------------------------------------------------

class PiesTester {
  public static void main (String[] args) {
    Pies p = new Pies();
    p.wielkosc = 40;
    p.szczekaj();
  }
}

