public class LodzWioslowa extends Lodz {
  public void wioslowanie() {
    System.out.println("wiosłuj Natasza ");
  }
}