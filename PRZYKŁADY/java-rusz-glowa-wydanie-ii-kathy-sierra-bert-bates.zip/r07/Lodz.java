public class Lodz { 
  private int dlugosc;
  public void setDlugosc ( int dl ) {
    dlugosc = dl;
  }
  public int getDlugosc() {
    return dlugosc;
  }
  public void plyn() {
    System.out.print("dryfuje ");
  }
}