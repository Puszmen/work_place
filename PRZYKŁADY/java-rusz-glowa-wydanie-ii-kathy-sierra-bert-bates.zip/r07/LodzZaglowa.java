public class LodzZaglowa extends Lodz {
  public void plyn() {
    System.out.print("stawiać żagle "); 
  }
}