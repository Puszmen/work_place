class test { 
  public static void main(String[] args) {
    String liczba = "2";
    int x = 2;
    
    boolean b = true;
    
    x = (int) b;
  }
}