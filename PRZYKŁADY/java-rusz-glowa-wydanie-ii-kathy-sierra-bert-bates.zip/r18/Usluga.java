import javax.swing.*;
import java.io.*;

public interface Usluga extends Serializable { 
    public JPanel pobierzPanelGUI();
}
