public class Kot extends Zwierze { 
  public void jedz() {}
  public void wedruj() {}
}