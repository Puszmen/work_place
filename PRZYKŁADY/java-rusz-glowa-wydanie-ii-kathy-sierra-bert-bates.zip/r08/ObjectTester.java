public class ObjectTester { 
  public static void main(String[] args) {
    Pies p = new Pies();
    Kot k = new Kot();
    
    System.out.println(k.toString());
  }
}