public class Pies extends Zwierze { 
  public void jedz() {}
  public void wedruj() {}
}